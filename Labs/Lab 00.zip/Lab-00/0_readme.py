# Databricks notebook source
# MAGIC %md
# MAGIC #Readme
# MAGIC
# MAGIC - ## Run 1_initialize
# MAGIC Required for subsequent notebooks to work
# MAGIC - ## 2_Intro-basics
# MAGIC - ## 3_Intro-readwrite
# MAGIC - ## 4_Intro-spark