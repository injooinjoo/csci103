# Databricks notebook source
# This cell is idempotent.
spark.sql('CREATE CATALOG IF NOT EXISTS cscie103_catalog');
spark.sql('USE CATALOG cscie103_catalog')

spark.sql('CREATE SCHEMA IF NOT EXISTS lab_02');
spark.sql('USE cscie103_catalog.lab_02')

spark.sql('CREATE VOLUME IF NOT EXISTS input')
spark.sql('CREATE VOLUME IF NOT EXISTS output')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading in our initial dataset
# MAGIC
# MAGIC For this first section, we're going to be working with a set of Apache log files. These log files are made available by Databricks via the `databricks-datasets` directory. This is made available right at the root directory. We'll get to reading in the data in a minute but accessing this data is a great example of what we can do inside of Databricks. We're going to use some functionality and data that Databricks provides. Firstly, we're going to use the Databricks Filesystem to list all of the [Databricks datasets](https://docs.databricks.com/data/databricks-datasets.html) that are available for you to use.

# COMMAND ----------

# MAGIC %fs ls dbfs:/databricks-datasets/

# COMMAND ----------

# MAGIC %md Inside of that folder you'll see the sample logs folder.

# COMMAND ----------

log_files = "/databricks-datasets/sample_logs"

# COMMAND ----------

# MAGIC %fs ls /databricks-datasets/sample_logs

# COMMAND ----------

# DBTITLE 1,Sample of log file
# MAGIC %fs head "/databricks-datasets/sample_logs/part-00000"

# COMMAND ----------

# MAGIC %md 
# MAGIC Create a function to parse out the different network access fields from each line of the log file using regex

# COMMAND ----------

log_files = "/databricks-datasets/sample_logs/"
raw_log_files_df = spark.read.text(log_files)
display(raw_log_files_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Use a regular expression to parse each log line in the source data into separate fields. It applies the regexp_extract function to the 'value' column for each field, creating a new DataFrame parsed_df with columns for IP address, user, timestamp, HTTP method, endpoint, protocol, status code, and content size. The display(parsed_df) command then shows the structured result as a table. This transforms unstructured log data into a structured format for further analysis.
# MAGIC

# COMMAND ----------

# DBTITLE 1,Regular Expression to add structure to the data

from pyspark.sql.functions import regexp_extract

log_pattern = r'^(\S+) - (\S+) \[([\w:/]+\s[+\-]\d+)\] "(\S+) (\S+) (\S+)" (\d+) (\d+)'

parsed_df = raw_log_files_df.select(
    regexp_extract('value', log_pattern, 1).alias('ip_address'),
    regexp_extract('value', log_pattern, 2).alias('user'),
    regexp_extract('value', log_pattern, 3).alias('timestamp'),
    regexp_extract('value', log_pattern, 4).alias('method'),
    regexp_extract('value', log_pattern, 5).alias('endpoint'),
    regexp_extract('value', log_pattern, 6).alias('protocol'),
    regexp_extract('value', log_pattern, 7).alias('status_code'),
    regexp_extract('value', log_pattern, 8).alias('content_size')
)

display(parsed_df)

# COMMAND ----------

parsed_df.count()

# COMMAND ----------

# MAGIC %md This shows us that we've got a total of 100,000 records. But we've still got to parse them. To do that we'll use DataFrame APIs that work on each record on the dataset. Now naturally this can happen in a distributed fashion across the cluster. This cluster is made up of executors that will execute computation when they are asked to do so by the primary master node or driver.
# MAGIC
# MAGIC [Spark Architecture](https://databricks.com/glossary/what-are-spark-applications)
# MAGIC
# MAGIC Driver programs access Apache Spark through a `SparkSession` object regardless of deployment location.
# MAGIC Note that, in Databricks you do not have to explicitly set up any sessions 
# MAGIC
# MAGIC Let's go ahead and perform a transformation by parsing the log files.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Now that we've set up the transformation for parsing this raw text file, we want to make it available in a more structured format. We'll do this by using the DataFrame and then a view (using `createOrReplaceTempView()`). This will give us the added advantage of working with the same dataset in multiple languages.

# COMMAND ----------

raw_log_files_df.createOrReplaceTempView("raw_log_files_view")

# COMMAND ----------

parsed_df.createOrReplaceTempView("log_data")

# COMMAND ----------

# MAGIC %md `CreateOrReplaceTempView` saves the data on the local spark session that we're working with. You won't find it in the `tables` button list on the left because it's not globally registered across all clusters, only this specific notebook session. That means that if we restart, our table will have to be re-registered. Now let's run some quick SQL to see how our parsing performed. This is an **action**, which specifies that Spark needs to perform some computation in order to return a result to the user.

# COMMAND ----------

# MAGIC %md 
# MAGIC Please note again that no computation has been started, we've only created a logical execution plan that has not been realized yet. In Apache Spark terminology we're specifying a **transformation**. By specifying transformations and not performing them right away, this allows Spark to do a lot of optimizations under the hood most relevantly, pipelining. Pipelining means that Spark will perform as much computation as it can in memory and in one stage as opposed to spilling to disk after each step.

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from raw_log_files_view

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from log_data

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from log_data

# COMMAND ----------

# MAGIC %md
# MAGIC # Note: This below cell will not work in Serverless Compute yet as it only supports SQL and Python 
# MAGIC We're also able to convert it into a Scala DataFrame by just performing a select all.
# MAGIC
# MAGIC Under the hood, Apache Spark DataFrames and SparkSQL are effectively the same. They operate with the same optimizer and have the same general functions that are made available to them.
# MAGIC

# COMMAND ----------

# %scala
# val scala_df = spark.sql("select * from log_data")
# display(scala_df)

# COMMAND ----------

# DBTITLE 1,Lets check the schema of the DataFrame
raw_log_files_df.printSchema()

# COMMAND ----------

# MAGIC %md Now before moving forward, let's display a bit of the data. Often times you'll want to see a bit of the data that you're working with, we can do this very easily using the `display` function that is available in all languages on a DataFrame or Dataset.

# COMMAND ----------

display(raw_log_files_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC As mentioned DataFrames and SparkSQL take advantage of the same optimizations and while we can specify our transformations by using and importing [SparkSQL functions](http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.functions$), I find it easier just to write the SQL to do my transformations.
# MAGIC
# MAGIC However, there's one issue here. Our datetime is not in a format that we can parse very easily. Let's go ahead and try to cast it to a timestamp and you'll see what I mean.

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT cast("21/Jun/2014:10:00:00 -0700" as timestamp) col_timestamp

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC What we get back is `null` meaning that the operation did not succeed. Luckily this gives us an awesome way of demonstrating the creation of a [UDF](https://spark.apache.org/docs/latest/sql-ref-functions-udf-scalar.html)
# MAGIC
# MAGIC
# MAGIC Creating UDFs in PySpark is very simple, you just define a python function then register it as a UDF. Now this function is a bit involved but the short of it is that we need to convert our date into a well formatted datetime. More specifically we're going to want to define a function that takes in a string, splits on the space character. Converts the hour offset to a form that we can offset our date by and adds it to our newly created datetime.

# COMMAND ----------

import time
import datetime


def parseDate(rawDate):
  element = datetime.datetime.strptime(rawDate,"%d/%b/%Y:%H:%M:%S %z")
  return datetime.datetime.timestamp(element)

example = "21/Jun/2014:10:32:00 -0730"
print(parseDate(example))


# COMMAND ----------

# MAGIC %md Now there are two different ways to register a UDF and we'll do both of them just to be clear about how to do it. The first is by using the `udf` function from `org.apache.spark.sql.functions`. This will allow you to use it on DataFrame columns.

# COMMAND ----------

from pyspark.sql.types import FloatType
parseDateUdf = udf(lambda x: parseDate(x), FloatType())

# COMMAND ----------

from pyspark.sql.functions import col
display(parsed_df.select(parseDateUdf('timestamp').alias("dtTimestamp")))

# COMMAND ----------

# MAGIC %md The other way is to register it with the `sqlContext`. This will allow you to use it inside of plain SQL as opposed to operating on a DataFrame column.

# COMMAND ----------

spark.udf.register("parseDate", parseDate, FloatType())

# COMMAND ----------

# MAGIC %sql 
# MAGIC describe log_data

# COMMAND ----------


clean_logs_df = spark.sql("""
SELECT 
  int(content_size) as contentSize, timestamp, parseDate(timestamp) as dtTimestamp, 
  from_unixtime(parseDate(timestamp), 'MM-dd-yyyy HH:mm:ss')  as dtFormatted,
  endpoint, ip_address as ipAddress, method, protocol, int(status_code) as responseCode, user as userId 
FROM log_data
""")
# clientIdentd, 
display(clean_logs_df)

# COMMAND ----------

# MAGIC %md Another way of performing the above computation is by using the `selectExpr` method with allows you to use SQL expressions on a DataFrame.

# COMMAND ----------

clean_logs_dfv2 = parsed_df.selectExpr(" int(content_size) as contentSize","timestamp", "from_unixtime(parseDate(timestamp), 'MM-dd-yyyy HH:mm:ss')  as dtFormatted","endpoint"," ip_address"," method"," protocol"," int(status_code) as responseCode","user as userId")
# "clientIdentd"
display(clean_logs_dfv2)

# COMMAND ----------

# MAGIC %md What's great about this is now we've got this UDF and we can reuse it in a variety of different languages (if we register it with the `sqlContext`). Now that we've created the plan for how to create this DataFrame - let's go ahead and run the `explain` method. This will give us the entire logical (and physical) instructions for Apache Spark to recalculate that DataFrame. Notice that this goes down to the raw RDD (and text file!) that we created in python at the top of the notebook!

# COMMAND ----------

clean_logs_dfv2.explain(mode='formatted')

# COMMAND ----------

# MAGIC %sh
# MAGIC wget https://raw.githubusercontent.com/for-GET/know-your-http-well/master/json/status-codes.json -P /Volumes/cscie103_catalog/lab_02/input

# COMMAND ----------

userDir = "/Volumes/cscie103_catalog/lab_02"

# COMMAND ----------

dbutils.fs.cp(f"{userDir}/input/status-codes.json", f"{userDir}/output/statuscodes", True)

# COMMAND ----------

status_codes_df = spark.read.option("multiline", "true").json(f"{userDir}/output/statuscodes/")
display(status_codes_df)

# COMMAND ----------

# MAGIC %md We will join the status code data with our first DataFrame in order to illustrate how you go about joining datasets. When we perform this join we will be generating a new DataFrame. In fact, you can think of it just as another transformation.

# COMMAND ----------

network_df = clean_logs_df.join(
    status_codes_df,
    clean_logs_df.responseCode.cast("string") == status_codes_df.code,
    "inner"
)
display(network_df)

# COMMAND ----------

# MAGIC %md Let's go ahead and merge this data with our status codes dataset. It provides a nice way to simulate what it's like to run a more sophisticated pipeline.

# COMMAND ----------

network_filtered_df = network_df.filter("code == '200' and contentSize > 100")
display(network_filtered_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Write to a Delta table

# COMMAND ----------

network_filtered_df.write.format('delta').mode('overwrite').saveAsTable('networkfilter')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM networkfilter